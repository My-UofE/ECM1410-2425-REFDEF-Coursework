## GamesLeague TestOperation system

The files in this directory are provided so you can verify your code is compatible with the coursework specifications (and therefore the grading script which will award marks for operation).

Further tests will be added in due course - keep an eye on the announcements forum to find out when updates are available.

To run the test scripts:

1. Make sure the class binaries for your `GamesLeague` package is all up to date (remember to repeat each time you make a change to files in your `GamesLeague` directory.)

```sh
javac -d bin -cp bin ./src/gamesleague/*.java
```

2. Build the TestOperation programs

```sh
javac -cp bin ./TestOperation/*.java 
```

3. Run the TestOperationApp to run through all tests. 

   Look in the files in the TestOperation folder and check the output of your code is in line with that expected.


```sh
java -cp bin:TestOperation TestOperationApp
```
