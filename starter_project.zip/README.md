# ECM1410-2425-REFDEF-Coursework

Please see the coursework specification:

https://github.com/My-UofE/ECM1410-2425-REFDEF-Coursework/tree/main

The templates folder contains a skeleton `GamesLeague.java` class file that has been set up with placeholder methods to implement the specified interface in `GamesLeagueInterface.java`. 

You may copy this file to the `src/gamesleague` folder to save you manually creating it.

e.g. using:

```
cp ./templates/GamesLeague.java src/GamesLeague.java
```
