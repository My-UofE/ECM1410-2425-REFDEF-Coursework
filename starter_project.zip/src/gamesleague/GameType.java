package gamesleague;

public enum GameType {
    WORDLE,
    TETRIS;
}