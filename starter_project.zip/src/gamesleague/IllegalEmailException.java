package gamesleague;

public class IllegalEmailException extends RuntimeException {
    public IllegalEmailException(String m) {
        super(m);
    }
}
