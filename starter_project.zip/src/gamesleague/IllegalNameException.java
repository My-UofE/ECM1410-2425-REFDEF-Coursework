package gamesleague;

public class IllegalNameException extends RuntimeException {
    public IllegalNameException(String m) {
        super(m);
    }
}
