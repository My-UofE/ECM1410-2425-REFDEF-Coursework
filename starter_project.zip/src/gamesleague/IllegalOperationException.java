package gamesleague;

public class IllegalOperationException extends RuntimeException {
    public IllegalOperationException(String m) {
        super(m);
    }
}
