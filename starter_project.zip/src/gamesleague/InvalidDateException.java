package gamesleague;

public class InvalidDateException extends RuntimeException {
    public InvalidDateException(String m) {
        super(m);
    }
}
