package gamesleague;

public class InvalidNameException extends RuntimeException {
    public InvalidNameException(String m) {
        super(m);
    }
}
