package gamesleague;

public enum Status {
    PENDING, 
    IN_PROGRESS, 
    CLOSED;
}